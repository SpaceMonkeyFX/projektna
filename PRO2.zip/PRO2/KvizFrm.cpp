///-----------------------------------------------------------------
///
/// @file      KvizFrm.cpp
/// @author    ZK
/// Created:   18.12.2017 14:55:11
/// @section   DESCRIPTION
///            KvizFrm class implementation
///
///------------------------------------------------------------------

#include "KvizFrm.h"

//Do not add custom headers between
//Header Include Start and Header Include End
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// KvizFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(KvizFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(KvizFrm::OnClose)
END_EVENT_TABLE()
////Event Table End

KvizFrm::KvizFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

KvizFrm::~KvizFrm()
{
}

void KvizFrm::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	Odgovor4 = new wxStaticText(this, ID_ODGOVOR4, _("Odgovor4"), wxPoint(144, 352), wxDefaultSize, 0, _("Odgovor4"));

	Odgovor3 = new wxStaticText(this, ID_ODGOVOR3, _("Odgovor3"), wxPoint(144, 304), wxDefaultSize, 0, _("Odgovor3"));

	Odgovor2 = new wxStaticText(this, ID_ODGOVR2, _("Odgovor2"), wxPoint(144, 256), wxDefaultSize, 0, _("Odgovor2"));

	Odgovor1 = new wxStaticText(this, ID_ODGOVOR1, _("Odgovor1"), wxPoint(144, 208), wxDefaultSize, 0, _("Odgovor1"));

	Vprasanje = new wxStaticText(this, ID_VPRASANJE, _("Vprasanje"), wxPoint(24, 56), wxDefaultSize, 0, _("Vprasanje"));

	D = new wxButton(this, ID_D, _("D"), wxPoint(40, 344), wxSize(75, 25), 0, wxDefaultValidator, _("D"));

	C = new wxButton(this, ID_C, _("C"), wxPoint(40, 296), wxSize(75, 25), 0, wxDefaultValidator, _("C"));

	B = new wxButton(this, ID_B, _("B"), wxPoint(40, 248), wxSize(75, 25), 0, wxDefaultValidator, _("B"));

	A = new wxButton(this, ID_A, _("A"), wxPoint(40, 200), wxSize(75, 25), 0, wxDefaultValidator, _("A"));

	SetTitle(_("Kviz"));
	SetIcon(wxNullIcon);
	SetSize(8,8,586,431);
	Center();
	
	////GUI Items Creation End
}

void KvizFrm::OnClose(wxCloseEvent& event)
{
	Destroy();
}
