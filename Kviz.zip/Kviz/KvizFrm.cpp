///-----------------------------------------------------------------
///
/// @file      KvizFrm.cpp
/// @author    ZK
/// Created:   18.12.2017 14:55:11
/// @section   DESCRIPTION
///            KvizFrm class implementation
///
///------------------------------------------------------------------

#include "KvizFrm.h"

//Do not add custom headers between
//Header Include Start and Header Include End
//wxDev-C++ designer will remove them
////Header Include Start
////Header Include End

//----------------------------------------------------------------------------
// KvizFrm
//----------------------------------------------------------------------------
//Add Custom Events only in the appropriate block.
//Code added in other places will be removed by wxDev-C++
////Event Table Start
BEGIN_EVENT_TABLE(KvizFrm,wxFrame)
	////Manual Code Start
	////Manual Code End
	
	EVT_CLOSE(KvizFrm::OnClose)
	EVT_ACTIVATE(KvizFrm::KvizFrmActivate)
END_EVENT_TABLE()
////Event Table End

KvizFrm::KvizFrm(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &position, const wxSize& size, long style)
: wxFrame(parent, id, title, position, size, style)
{
	CreateGUIControls();
}

KvizFrm::~KvizFrm()
{
}

void KvizFrm::CreateGUIControls()
{
	//Do not add custom code between
	//GUI Items Creation Start and GUI Items Creation End
	//wxDev-C++ designer will remove them.
	//Add the custom code before or after the blocks
	////GUI Items Creation Start

	WxEdit5 = new wxTextCtrl(this, ID_WXEDIT5, _("WxEdit5"), wxPoint(152, 272), wxSize(369, 27), 0, wxDefaultValidator, _("WxEdit5"));

	WxEdit4 = new wxTextCtrl(this, ID_WXEDIT4, _("WxEdit4"), wxPoint(152, 224), wxSize(377, 27), 0, wxDefaultValidator, _("WxEdit4"));

	WxEdit3 = new wxTextCtrl(this, ID_WXEDIT3, _("WxEdit3"), wxPoint(152, 176), wxSize(377, 27), 0, wxDefaultValidator, _("WxEdit3"));

	WxEdit2 = new wxTextCtrl(this, ID_WXEDIT2, _("WxEdit2"), wxPoint(152, 128), wxSize(377, 27), 0, wxDefaultValidator, _("WxEdit2"));

	WxEdit1 = new wxTextCtrl(this, ID_WXEDIT1, _("WxEdit1"), wxPoint(32, 40), wxSize(497, 59), 0, wxDefaultValidator, _("WxEdit1"));

	D = new wxButton(this, ID_D, _("D"), wxPoint(32, 272), wxSize(75, 25), 0, wxDefaultValidator, _("D"));

	C = new wxButton(this, ID_C, _("C"), wxPoint(32, 224), wxSize(75, 25), 0, wxDefaultValidator, _("C"));

	B = new wxButton(this, ID_B, _("B"), wxPoint(32, 176), wxSize(75, 25), 0, wxDefaultValidator, _("B"));

	A = new wxButton(this, ID_A, _("A"), wxPoint(32, 128), wxSize(75, 25), 0, wxDefaultValidator, _("A"));

	SetTitle(_("Kviz"));
	SetIcon(wxNullIcon);
	SetSize(8,8,586,393);
	Center();
	
	////GUI Items Creation End
}

void KvizFrm::OnClose(wxCloseEvent& event)
{
	Destroy();
}

/*
 * KvizFrmActivate
 */
void KvizFrm::KvizFrmActivate(wxActivateEvent& event)
{
	// insert your code here
	WxEdit1->SetValue("Kako si?");
}
